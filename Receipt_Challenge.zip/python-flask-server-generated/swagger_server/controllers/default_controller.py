import connexion
import random
import six
import gc
from swagger_server.models.inline_response200 import InlineResponse200  # noqa: E501
from swagger_server.models.inline_response2001 import InlineResponse2001  # noqa: E501
from swagger_server.models.receipt import Receipt  # noqa: E501
from swagger_server import util
ReceiptTracker=[]





def receipts_id_points_get(id_):  # noqa: E501
    """Returns the points awarded for the receipt.

    Returns the points awarded for the receipt. # noqa: E501

    :param id: The ID of the receipt.
    :type id: str

    :rtype: InlineResponse2001
    """
    
    print("id= "+ id_)
    I=InlineResponse2001(0)
    
    for R in ReceiptTracker:
        if (hasattr(R, 'id') is True):

            if(R.id==id_):

       
                I.points+= name_len(R)
                I.points+= round_dollar(R)
                I.points+= total_multiple(R)
                I.points+= two_items(R)
                I.points+= item_len(R)
                I.points+= odd_day(R)
                I.points+= time_check(R)
                print('\n')
                return I
                    
                  
    print("Could not find matching receipt to " + id_)
    return I



def name_len(R):
    print("name_len")
    i=0
    count=0
    while (i <len(R._retailer)):
        if(R._retailer[i].isalnum()):
            count+=1
        i+=1
    print(count)
    return count
        
def round_dollar(R):
    print("round_dollar")
    flt=float(R.total)
    if(flt-int(flt)==0):
        print(50)
        return 50
    print(0)
    return 0
    
def total_multiple(R):
    print("total_multiple")
    flt=float(R.total)
    
    
    if(flt%0.25==0.0):
        print(25)
        return 25
    print(0)
    return 0
    
def two_items(R):
    print("two_items")
    pairs=int(len(R._items)/2)

    
    print(5*pairs)
    return 5*pairs
    
def item_len(R):
    print("item_len")
    i=0
    points=0
      
    
    while(i<len(R._items)):

        if(len(R._items[i]["shortDescription"])%3==0):
            points+=-1*((float(R._items[i]["price"])*0.2)//-1)
        i+=1
    print(points)
    return points
    
def odd_day(R):
    print("odd_day")
    
    
    day=int(R._purchase_date[-2:])

    
    if(day%2!=0):
        print(6)
        return 6
    print(0)
    return 0
    
def time_check(R):
    print("time_check")
    
    
    convert_time=int(R._purchase_time[0:2]+R._purchase_time[3:])
    

    
    if(convert_time>200 and convert_time<400):
        print(10)
        return 10
    print(0)
    return 0


def receipts_process_post(body):  # noqa: E501
    """Submits a receipt for processing.

    Submits a receipt for processing. # noqa: E501

    :param body: 
    :type body: dict | bytes

    :rtype: InlineResponse200
    """

    #if connexion.request.is_json:
    #    body = Receipt.from_dict(connexion.request.get_json())  # noqa: E501
    ret=body["retailer"]
    pdt=body["purchaseDate"]
    pti=body["purchaseTime"]
    ite=body["items"]

    tot=body["total"]
    
    R=Receipt(ret,pdt,pti,ite,tot)
    ReceiptTracker.append(R)
    chars=['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    rand=random.choices(chars,k=32)
    ran=''.join(rand)
    R.id = ran[:8] + "-" + ran[8:12] + "-" + ran[12:16] + "-" + ran[16:20] + "-" + ran[20:]
    I=InlineResponse200(R.id)
    
    return I
